# 🛡️ CyberShield AI — SIH25160
### AI-Driven Next-Generation Firewall for Dynamic Threat Detection and Zero Trust Implementation

---

## 🚀 Quick Start (localhost in 60 seconds)

```bash
# 1. Install dependencies
npm install

# 2. Copy environment file
cp .env.example .env

# 3. Start the server
node server.js

# 4. Open browser
open http://localhost:3000
```

---

## 🔑 Demo Credentials

| Role     | Email                       | Password   |
|----------|-----------------------------|------------|
| Admin    | admin@cybershield.ai        | admin123   |
| Analyst  | analyst@cybershield.ai      | analyst123 |

---

## 📁 Project Structure

```
cybershield-ai/
├── server.js              ← Main Express + Socket.IO server
├── package.json
├── .env.example
├── README.md
│
├── routes/                ← REST API endpoints
│   ├── auth.js            ← POST /api/auth/login, /register, GET /me
│   ├── dashboard.js       ← GET /api/dashboard/metrics, /threats, /traffic
│   ├── incidents.js       ← CRUD + actions on security incidents
│   ├── intel.js           ← Threat feed, CVEs, blacklisted IPs
│   ├── eco.js             ← Green security metrics, tips, optimize
│   ├── firewall.js        ← Firewall rule CRUD + toggle
│   └── users.js           ← User management (admin only)
│
├── middleware/
│   └── auth.js            ← JWT verification middleware
│
├── data/
│   └── store.js           ← In-memory data store (swap for PostgreSQL)
│
└── public/
    └── index.html         ← Complete SPA frontend (all pages)
```

---

## 🌐 API Reference

### Authentication
| Method | Endpoint              | Description         |
|--------|-----------------------|---------------------|
| POST   | /api/auth/register    | Register new user   |
| POST   | /api/auth/login       | Login + trust score |
| GET    | /api/auth/me          | Get current user    |

### Dashboard
| Method | Endpoint                          | Description          |
|--------|-----------------------------------|----------------------|
| GET    | /api/dashboard/metrics            | SOC summary metrics  |
| GET    | /api/dashboard/threats            | Live threat list     |
| GET    | /api/dashboard/traffic            | Network traffic data |
| GET    | /api/dashboard/trust-breakdown    | Zero Trust scores    |
| GET    | /api/dashboard/audit-logs         | Security audit trail |

### Incidents
| Method | Endpoint                       | Description           |
|--------|--------------------------------|-----------------------|
| GET    | /api/incidents                 | List all incidents    |
| POST   | /api/incidents                 | Create incident       |
| POST   | /api/incidents/:id/action      | block/investigate/resolve |

### Threat Intelligence
| Method | Endpoint               | Description           |
|--------|------------------------|-----------------------|
| GET    | /api/intel/feed        | Live threat feed      |
| GET    | /api/intel/blacklisted | Blacklisted IPs       |
| POST   | /api/intel/blacklist   | Add IP to blocklist   |
| GET    | /api/intel/cves        | Active CVE list       |
| GET    | /api/intel/summary     | IOC summary stats     |

### Firewall
| Method | Endpoint                   | Description           |
|--------|----------------------------|-----------------------|
| GET    | /api/firewall              | List all rules        |
| POST   | /api/firewall              | Add new rule          |
| PATCH  | /api/firewall/:id/toggle   | Enable/disable rule   |
| DELETE | /api/firewall/:id          | Delete rule           |

### 🌿 Green Security
| Method | Endpoint            | Description              |
|--------|---------------------|--------------------------|
| GET    | /api/eco/metrics    | Live energy & CO₂ data   |
| GET    | /api/eco/tips       | 10 eco tips for analysts |
| POST   | /api/eco/optimize   | Trigger AI optimizer     |
| GET    | /api/eco/report     | Full eco report          |

### Users (Admin)
| Method | Endpoint       | Description      |
|--------|----------------|------------------|
| GET    | /api/users     | List all users   |
| GET    | /api/users/:id | Get user profile |

---

## 🏗️ Tech Stack

### Backend
- **Node.js** + **Express.js** — REST API
- **Socket.IO** — Real-time threat & eco event streaming
- **bcryptjs** — Password hashing
- **jsonwebtoken** — JWT auth with trust scoring
- **cors** + **dotenv**

### Frontend (Single Page App)
- Vanilla HTML/CSS/JS — zero framework overhead
- **Chart.js** — Traffic, threat distribution, eco charts
- **Socket.IO client** — Live threat feed
- Glassmorphism UI, Neon Blue (#00E5FF), Poppins + Inter fonts

### Zero Trust Implementation
- Device posture scoring
- Geo-location verification
- Behavioral baseline checking
- MFA status verification
- Composite trust score per login (80–98%)

### 🌿 Green Security Features
- AI-powered resource optimizer (saves 34% energy)
- Live power consumption tracking (kW)
- CO₂ offset calculation (12.4t saved)
- 10 actionable eco tips for SOC analysts
- Off-peak scanning mode (10 PM–6 AM)
- Carbon footprint report generation

---

## 🔌 Real-Time Features (Socket.IO)

The server emits events every few seconds:
- `threat` — New threat detected (name, severity, IP, score)
- `eco` — Updated power consumption (kW, CO₂ offset)
- `traffic` — Live network stats (Gbps, packets/sec, blocked)

---

## 🗄️ Upgrading to PostgreSQL

The `data/store.js` file uses in-memory arrays. To use PostgreSQL:

1. `npm install prisma @prisma/client`
2. `npx prisma init`
3. Define schema in `prisma/schema.prisma`
4. Replace array operations in `data/store.js` with Prisma queries

---

## 🚀 Deployment

| Component | Platform      |
|-----------|---------------|
| Frontend  | Vercel        |
| Backend   | Render        |
| Database  | Neon PostgreSQL |
| Storage   | Supabase      |

---

## 👥 User Roles

| Role             | Permissions                                          |
|------------------|------------------------------------------------------|
| Super Admin      | Full access + user management                        |
| Security Analyst | Dashboard, threats, incidents, firewall              |
| Org Admin        | Own org's data + reports                             |
| Auditor          | Read-only access to logs and reports                 |

---

*Built for Smart India Hackathon 2025 — Problem Statement SIH25160*  
*🌿 Carbon-neutral infrastructure · Made in India 🇮🇳*
