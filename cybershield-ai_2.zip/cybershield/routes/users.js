const router = require('express').Router();
const auth = require('../middleware/auth');
const { users } = require('../data/store');

// Admin only — list all users
router.get('/', auth, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin access required' });
  res.json(users.map(u => ({ id: u.id, name: u.name, email: u.email, role: u.role, org: u.org, createdAt: u.createdAt })));
});

// Get single user profile (own profile or admin)
router.get('/:id', auth, (req, res) => {
  const id = parseInt(req.params.id);
  if (req.user.id !== id && req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  const user = users.find(u => u.id === id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ id: user.id, name: user.name, email: user.email, role: user.role, org: user.org });
});

module.exports = router;
