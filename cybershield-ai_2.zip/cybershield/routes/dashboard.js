const router = require('express').Router();
const auth = require('../middleware/auth');
const { incidents, auditLogs } = require('../data/store');

router.get('/metrics', auth, (req, res) => {
  res.json({
    threatsBlocked:  1300 + Math.floor(Math.random() * 100),
    activeDevices:   847,
    networkGbps:     parseFloat((1.8 + Math.random() * 1.2).toFixed(1)),
    avgTrustScore:   88,
    aiAccuracy:      97.2,
    openIncidents:   incidents.filter(i => i.status === 'open').length,
    falsePositiveRate: 0.3,
    blockedIPs:      8432,
  });
});

router.get('/threats', auth, (req, res) => {
  const types   = ['LockBit Ransomware', 'SQL Injection', 'Credential Stuffing', 'Port Scan', 'DDoS Flood', 'Phishing Email', 'Zero-Day Probe', 'Insider Exfiltration'];
  const sevs    = ['critical', 'critical', 'high', 'high', 'medium', 'low'];
  const ips     = ['45.142.212.100','198.54.117.210','91.108.4.144','185.220.101.42','192.42.116.14','203.0.113.44'];
  res.json(Array.from({ length: 6 }, (_, i) => ({
    id:        i + 1,
    name:      types[i % types.length],
    severity:  sevs[Math.floor(Math.random() * sevs.length)],
    score:     Math.floor(40 + Math.random() * 55),
    ip:        ips[i % ips.length],
    type:      ['Malware','Web Attack','Auth Attack','Recon','DDoS','Phishing'][i % 6],
    timestamp: Date.now() - i * 90000,
  })));
});

router.get('/traffic', auth, (req, res) => {
  const labels = Array.from({ length: 12 }, (_, i) => `${(i * 2).toString().padStart(2, '0')}:00`);
  res.json({
    labels,
    traffic:  labels.map(() => parseFloat((0.8 + Math.random() * 2.8).toFixed(1))),
    threats:  labels.map(() => Math.floor(5 + Math.random() * 80)),
    blocked:  labels.map(() => Math.floor(2 + Math.random() * 40)),
  });
});

router.get('/trust-breakdown', auth, (req, res) => {
  res.json([
    { label: 'Device posture',   score: Math.floor(88 + Math.random() * 10), color: '#00E5A0' },
    { label: 'Geo-location',     score: Math.floor(82 + Math.random() * 14), color: '#00E5A0' },
    { label: 'Behavioral score', score: Math.floor(70 + Math.random() * 20), color: '#00E5FF' },
    { label: 'MFA verified',     score: 100,                                  color: '#00E5A0' },
    { label: 'Identity check',   score: Math.floor(90 + Math.random() * 9),  color: '#00E5A0' },
  ]);
});

router.get('/audit-logs', auth, (req, res) => {
  res.json(auditLogs);
});

module.exports = router;
