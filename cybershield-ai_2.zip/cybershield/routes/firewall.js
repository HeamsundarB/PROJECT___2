const router = require('express').Router();
const auth = require('../middleware/auth');
const { firewallRules, auditLogs } = require('../data/store');

router.get('/',    auth, (req, res) => res.json(firewallRules));

router.post('/', auth, (req, res) => {
  const { name, action, protocol, src, dst, port } = req.body;
  if (!name || !action) return res.status(400).json({ error: 'Name and action are required' });
  const rule = { id: firewallRules.length + 1, name, action: action.toUpperCase(), protocol: protocol || 'TCP', src: src || 'any', dst: dst || 'any', port: port || 'any', active: true, hits: 0 };
  firewallRules.push(rule);
  auditLogs.unshift({ id: auditLogs.length + 1, user: req.user.email, action: 'FIREWALL_RULE_ADDED', detail: `Rule #${rule.id}: ${name}`, time: Date.now() });
  res.status(201).json(rule);
});

router.patch('/:id/toggle', auth, (req, res) => {
  const rule = firewallRules.find(r => r.id === parseInt(req.params.id));
  if (!rule) return res.status(404).json({ error: 'Rule not found' });
  rule.active = !rule.active;
  res.json({ success: true, rule });
});

router.delete('/:id', auth, (req, res) => {
  const idx = firewallRules.findIndex(r => r.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ error: 'Rule not found' });
  firewallRules.splice(idx, 1);
  res.json({ success: true, message: 'Rule deleted' });
});

module.exports = router;
