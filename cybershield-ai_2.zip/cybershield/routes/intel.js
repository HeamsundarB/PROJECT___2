const router = require('express').Router();
const auth = require('../middleware/auth');
const { threatFeed, blacklistedIPs, cveList } = require('../data/store');

router.get('/feed',         auth, (req, res) => res.json(threatFeed));
router.get('/blacklisted',  auth, (req, res) => res.json(blacklistedIPs));
router.get('/cves',         auth, (req, res) => res.json(cveList));

router.get('/summary', auth, (req, res) => {
  res.json({
    activeIOCs: 1247,
    blockedIPs: 8432,
    newCVEs24h: 23,
    malwareSigs: '2.1M',
    lastUpdated: new Date().toISOString(),
  });
});

router.post('/blacklist', auth, (req, res) => {
  const { ip, reason } = req.body;
  if (!ip) return res.status(400).json({ error: 'IP address required' });
  if (blacklistedIPs.find(b => b.ip === ip)) return res.status(409).json({ error: 'IP already blacklisted' });
  const entry = { ip, reason: reason || 'Manual block', country: 'XX', firstSeen: new Date().toISOString().slice(0,10), hits: 0 };
  blacklistedIPs.push(entry);
  res.status(201).json({ success: true, entry });
});

module.exports = router;
