const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { JWT_SECRET, users } = require('../data/store');

// POST /api/auth/register
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, role, org } = req.body;
    if (!name || !email || !password) return res.status(400).json({ error: 'Name, email and password are required' });
    if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });
    if (users.find(u => u.email === email)) return res.status(409).json({ error: 'Email already registered' });
    const hash = await bcrypt.hash(password, 12);
    const newUser = { id: users.length + 1, name, email, password: hash, role: role || 'analyst', org: org || 'My Organization', createdAt: new Date() };
    users.push(newUser);
    const trustScore = Math.floor(80 + Math.random() * 18);
    const token = jwt.sign({ id: newUser.id, email, role: newUser.role, trust: trustScore }, JWT_SECRET, { expiresIn: '24h' });
    res.status(201).json({ token, user: { id: newUser.id, name, email, role: newUser.role, org: newUser.org }, trustScore });
  } catch (e) { res.status(500).json({ error: 'Server error during registration' }); }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
    const user = users.find(u => u.email === email);
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });
    // Allow demo plain-text shortcut passwords
    const demoPasswords = { 'admin@cybershield.ai': 'admin123', 'analyst@cybershield.ai': 'analyst123' };
    const isDemoMatch = demoPasswords[email] === password;
    const isHashMatch = await bcrypt.compare(password, user.password).catch(() => false);
    if (!isDemoMatch && !isHashMatch) return res.status(401).json({ error: 'Invalid credentials' });
    const trustScore = Math.floor(80 + Math.random() * 18);
    const token = jwt.sign({ id: user.id, email, role: user.role, trust: trustScore }, JWT_SECRET, { expiresIn: '24h' });
    res.json({ token, user: { id: user.id, name: user.name, email, role: user.role, org: user.org }, trustScore });
  } catch (e) { res.status(500).json({ error: 'Server error during login' }); }
});

// GET /api/auth/me
router.get('/me', require('../middleware/auth'), (req, res) => {
  const user = users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ id: user.id, name: user.name, email: user.email, role: user.role, org: user.org });
});

module.exports = router;
