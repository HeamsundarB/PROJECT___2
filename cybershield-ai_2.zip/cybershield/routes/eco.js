const router = require('express').Router();
const auth = require('../middleware/auth');
const { ecoMetrics, ecoTips } = require('../data/store');

router.get('/metrics', auth, (req, res) => {
  ecoMetrics.currentPowerKw = parseFloat((1.6 + Math.random() * 0.9).toFixed(2));
  res.json({ ...ecoMetrics });
});

router.get('/tips', auth, (req, res) => res.json(ecoTips));

router.post('/optimize', auth, (req, res) => {
  ecoMetrics.energySavedPercent = Math.min(50, ecoMetrics.energySavedPercent + 2);
  ecoMetrics.aiOptimizerWatts  = Math.min(500, ecoMetrics.aiOptimizerWatts + 20);
  ecoMetrics.co2SavedKg        += 5;
  res.json({ success: true, message: `AI optimizer boosted — additional 20W saved, +5 kg CO₂ offset`, metrics: ecoMetrics });
});

router.get('/report', auth, (req, res) => {
  res.json({
    period: 'Q2 2025',
    energySavedKWh: 8400,
    co2SavedKg: ecoMetrics.co2SavedKg,
    treesEquivalent: ecoMetrics.treesEquivalent,
    avgPowerKw: 2.1,
    peakPowerKw: 3.2,
    offPeakSavings: '22%',
    recommendations: [
      'Expand off-peak scanning window from 8h to 10h',
      'Migrate report generation to low-carbon cloud region',
      'Enable aggressive sleep on 12 idle analyst workstations',
    ],
    score: 'A+',
  });
});

module.exports = router;
