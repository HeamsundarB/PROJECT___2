const router = require('express').Router();
const auth = require('../middleware/auth');
const { incidents, auditLogs } = require('../data/store');

router.get('/', auth, (req, res) => {
  const { status, severity } = req.query;
  let list = [...incidents];
  if (status)   list = list.filter(i => i.status === status);
  if (severity) list = list.filter(i => i.severity === severity);
  res.json(list.sort((a, b) => {
    const order = { critical: 0, high: 1, medium: 2, low: 3 };
    return (order[a.severity] ?? 4) - (order[b.severity] ?? 4);
  }));
});

router.get('/:id', auth, (req, res) => {
  const inc = incidents.find(i => i.id === parseInt(req.params.id));
  if (!inc) return res.status(404).json({ error: 'Incident not found' });
  res.json(inc);
});

router.post('/', auth, (req, res) => {
  const { title, severity, ip } = req.body;
  if (!title) return res.status(400).json({ error: 'Title is required' });
  const newInc = { id: incidents.length + 1, title, severity: severity || 'medium', status: 'open', ip: ip || 'Unknown', affected: 0, time: Date.now() };
  incidents.push(newInc);
  auditLogs.unshift({ id: auditLogs.length + 1, user: req.user.email, action: 'INCIDENT_CREATED', detail: `Incident #${newInc.id}: ${title}`, time: Date.now() });
  res.status(201).json(newInc);
});

router.post('/:id/action', auth, (req, res) => {
  const inc = incidents.find(i => i.id === parseInt(req.params.id));
  if (!inc) return res.status(404).json({ error: 'Incident not found' });
  const { action } = req.body;
  const validActions = ['block', 'investigate', 'resolve', 'quarantine'];
  if (!validActions.includes(action)) return res.status(400).json({ error: 'Invalid action' });
  if (action === 'resolve')     inc.status = 'resolved';
  if (action === 'investigate') inc.status = 'investigating';
  if (action === 'quarantine')  inc.status = 'quarantined';
  auditLogs.unshift({ id: auditLogs.length + 1, user: req.user.email, action: `INCIDENT_${action.toUpperCase()}`, detail: `Incident #${inc.id} — ${action}`, time: Date.now() });
  res.json({ success: true, incident: inc, message: `Action '${action}' applied to incident #${inc.id}` });
});

module.exports = router;
