require('dotenv').config();
const express  = require('express');
const http     = require('http');
const { Server } = require('socket.io');
const cors     = require('cors');
const path     = require('path');

const app    = express();
const server = http.createServer(app);
const io     = new Server(server, { cors: { origin: '*' } });
const PORT   = process.env.PORT || 3000;

// ── Middleware ──────────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── API Routes ──────────────────────────────────────────────────────────────
app.use('/api/auth',       require('./routes/auth'));
app.use('/api/dashboard',  require('./routes/dashboard'));
app.use('/api/incidents',  require('./routes/incidents'));
app.use('/api/intel',      require('./routes/intel'));
app.use('/api/eco',        require('./routes/eco'));
app.use('/api/firewall',   require('./routes/firewall'));
app.use('/api/users',      require('./routes/users'));

// ── Health check ────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => res.json({ status: 'ok', version: '1.0.0', time: new Date() }));

// ── Serve SPA ───────────────────────────────────────────────────────────────
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

// ── Socket.IO — real-time threat & eco events ───────────────────────────────
const THREAT_TYPES = ['LockBit Ransomware','SQL Injection','Credential Stuffing','Port Scan','DDoS Flood','Phishing','Zero-Day Probe','ARP Spoof'];
const SEVERITIES   = ['critical','critical','high','high','medium','low'];
const IPS          = ['45.142.212.100','198.54.117.210','91.108.4.144','185.220.101.42','203.0.113.44','192.168.99.14'];

io.on('connection', (socket) => {
  console.log(`[Socket] Client connected: ${socket.id}`);

  // Live threat feed every 4s
  const threatTimer = setInterval(() => {
    socket.emit('threat', {
      name:      THREAT_TYPES[Math.floor(Math.random() * THREAT_TYPES.length)],
      severity:  SEVERITIES[Math.floor(Math.random() * SEVERITIES.length)],
      ip:        IPS[Math.floor(Math.random() * IPS.length)],
      score:     Math.floor(30 + Math.random() * 65),
      timestamp: Date.now(),
    });
  }, 4000);

  // Live eco metrics every 5s
  const ecoTimer = setInterval(() => {
    socket.emit('eco', {
      powerKw:        parseFloat((1.6 + Math.random() * 0.9).toFixed(2)),
      co2OffsetGrams: parseFloat((Math.random() * 2).toFixed(1)),
    });
  }, 5000);

  // Live traffic stats every 6s
  const trafficTimer = setInterval(() => {
    socket.emit('traffic', {
      gbps:          parseFloat((1.2 + Math.random() * 2.2).toFixed(1)),
      packetsPerSec: Math.floor(80000 + Math.random() * 40000),
      blocked:       Math.floor(Math.random() * 15),
    });
  }, 6000);

  socket.on('disconnect', () => {
    clearInterval(threatTimer);
    clearInterval(ecoTimer);
    clearInterval(trafficTimer);
    console.log(`[Socket] Client disconnected: ${socket.id}`);
  });
});

// ── Start ───────────────────────────────────────────────────────────────────
server.listen(PORT, () => {
  console.log('\n' + '═'.repeat(52));
  console.log('  🛡️  CyberShield AI — SIH25160');
  console.log('═'.repeat(52));
  console.log(`  🌐  http://localhost:${PORT}`);
  console.log('─'.repeat(52));
  console.log('  Demo credentials:');
  console.log('  👑  admin@cybershield.ai    / admin123');
  console.log('  🔍  analyst@cybershield.ai  / analyst123');
  console.log('─'.repeat(52));
  console.log('  🌿  Green mode: active — carbon-neutral SOC');
  console.log('═'.repeat(52) + '\n');
});
