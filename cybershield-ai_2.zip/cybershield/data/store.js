// In-memory data store (replace with PostgreSQL/Prisma in production)
const JWT_SECRET = process.env.JWT_SECRET || 'cybershield-sih25160-secret';

const users = [
  { id: 1, name: 'Admin User',    email: 'admin@cybershield.ai',   password: '$2a$10$YJ3QKdS9qK1j0x2e1u9mEuiE5J7T3pQk6Rz1qW0hN4vL8mD2sO6Yi', role: 'admin',   org: 'CyberShield' },
  { id: 2, name: 'Priya Sharma',  email: 'analyst@cybershield.ai', password: '$2a$10$YJ3QKdS9qK1j0x2e1u9mEuiE5J7T3pQk6Rz1qW0hN4vL8mD2sO6Yi', role: 'analyst', org: 'CyberShield' },
];
// Both demo passwords = "demo1234" (bcrypt hash above)
// Plain-text demo for quick login: admin@cybershield.ai / admin123  |  analyst@cybershield.ai / analyst123

const incidents = [
  { id: 1, title: 'Ransomware activity — finance subnet', severity: 'critical', status: 'open',         ip: '192.168.12.44',    affected: 3,  time: Date.now() - 720000  },
  { id: 2, title: 'DDoS amplification via DNS',           severity: 'high',     status: 'open',         ip: 'Multiple',         affected: 0,  time: Date.now() - 1680000 },
  { id: 3, title: 'Brute force login — admin portal',     severity: 'high',     status: 'investigating', ip: '45.142.212.100',   affected: 0,  time: Date.now() - 3600000 },
  { id: 4, title: 'Suspicious outbound data transfer',    severity: 'medium',   status: 'open',         ip: '192.168.1.47',     affected: 1,  time: Date.now() - 7200000 },
  { id: 5, title: 'Port scan from external source',       severity: 'low',      status: 'resolved',     ip: '198.54.117.210',   affected: 0,  time: Date.now() - 10800000},
];

const firewallRules = [
  { id: 1, name: 'Block LockBit C2',       action: 'DENY',   protocol: 'TCP', src: '45.142.212.100', dst: 'any',  port: 'any',     active: true,  hits: 1342 },
  { id: 2, name: 'Block SQL Injection',     action: 'DENY',   protocol: 'TCP', src: 'any',           dst: 'any',  port: '80,443',  active: true,  hits: 8741 },
  { id: 3, name: 'Allow HTTPS Outbound',   action: 'ALLOW',  protocol: 'TCP', src: 'internal',      dst: 'any',  port: '443',     active: true,  hits: 284920 },
  { id: 4, name: 'Block Tor Exit Nodes',   action: 'DENY',   protocol: 'ANY', src: 'tor-list',      dst: 'any',  port: 'any',     active: true,  hits: 234 },
  { id: 5, name: 'Allow DNS',              action: 'ALLOW',  protocol: 'UDP', src: 'internal',      dst: '8.8.8.8', port: '53', active: true,  hits: 129843 },
];

const threatFeed = [
  { severity: 'critical', event: 'New C2 domain zyx[.]onion added to global blocklist',       country: 'RU', time: '2 min ago'  },
  { severity: 'critical', event: 'CVE-2024-3094 (XZ Utils backdoor) active exploitation',     country: 'CN', time: '5 min ago'  },
  { severity: 'high',     event: 'Phishing campaign targeting Indian BFSI sector via email',  country: 'NG', time: '11 min ago' },
  { severity: 'critical', event: 'LockBit 3.0 new variant — updated signature deployed',      country: 'XX', time: '18 min ago' },
  { severity: 'high',     event: 'DDoS amplification using exposed NTP servers (2.4 Gbps)',   country: 'US', time: '25 min ago' },
  { severity: 'medium',   event: 'Credential dump (450K records) circulating on dark web',   country: 'TR', time: '40 min ago' },
  { severity: 'high',     event: 'Emotet v5 phishing wave — 12K emails blocked globally',    country: 'DE', time: '52 min ago' },
];

const blacklistedIPs = [
  { ip: '185.220.101.42', reason: 'C2 Server',   country: 'RU', firstSeen: '2024-01-12', hits: 847  },
  { ip: '91.108.4.144',   reason: 'Botnet node', country: 'NL', firstSeen: '2024-02-08', hits: 1203 },
  { ip: '198.54.117.210', reason: 'Port scanner', country: 'US', firstSeen: '2024-03-15', hits: 442 },
  { ip: '45.142.212.100', reason: 'Ransomware',  country: 'RO', firstSeen: '2024-04-01', hits: 234  },
  { ip: '192.42.116.14',  reason: 'Tor exit',    country: 'DE', firstSeen: '2024-04-22', hits: 89   },
];

const cveList = [
  { id: 'CVE-2024-3094',  desc: 'XZ Utils backdoor — remote code execution',         cvss: 10.0, severity: 'critical', status: 'active'   },
  { id: 'CVE-2024-21413', desc: 'Microsoft Outlook remote code execution',            cvss: 9.8,  severity: 'critical', status: 'active'   },
  { id: 'CVE-2024-26169', desc: 'Windows Error Reporting privilege escalation',       cvss: 7.8,  severity: 'high',    status: 'active'   },
  { id: 'CVE-2024-29988', desc: 'SmartScreen filter bypass',                         cvss: 8.8,  severity: 'high',    status: 'patched'  },
  { id: 'CVE-2024-30051', desc: 'Windows DWM Core Library privilege escalation',     cvss: 7.8,  severity: 'high',    status: 'active'   },
];

const ecoMetrics = {
  energySavedPercent: 34,
  co2SavedKg: 12400,
  currentPowerKw: 2.1,
  efficiencyPercent: 78,
  treesEquivalent: 247,
  aiOptimizerWatts: 340,
  carbonPerQuery: 0.0,
  offPeakActive: true,
  history: Array.from({ length: 24 }, (_, i) => ({
    hour: i,
    powerKw: parseFloat((2.5 - Math.sin(i / 3) * 0.6 + (Math.random() * 0.2 - 0.1)).toFixed(2)),
    threatsBlocked: Math.floor(10 + Math.random() * 80),
  })),
};

const ecoTips = [
  { id: 1, icon: '💡', tip: 'Turn off monitors when stepping away for more than 5 minutes',           impact: 'Saves ~15W per monitor hour' },
  { id: 2, icon: '🌙', tip: 'Enable dark mode on all dashboards — OLED panels save up to 30% power', impact: 'Saves ~8W per screen' },
  { id: 3, icon: '🔌', tip: 'Unplug chargers when not in use — phantom load adds up overnight',       impact: 'Saves ~2–5W continuously' },
  { id: 4, icon: '📶', tip: 'Disable WiFi on unused analyst devices to reduce scan overhead',          impact: 'Reduces SOC processing 3%' },
  { id: 5, icon: '🖨️', tip: 'Use PDF exports instead of printing reports',                            impact: 'Saves ~0.5 kg CO₂ per report' },
  { id: 6, icon: '♻️', tip: 'Schedule batch threat scans during off-peak hours (10 PM–6 AM)',         impact: 'Cuts peak load by 22%' },
  { id: 7, icon: '🌿', tip: 'Close unused browser tabs — each tab consumes 10–20 MB RAM',             impact: 'Reduces CPU/GPU usage 8%' },
  { id: 8, icon: '🌡️', tip: 'Keep server room at 22°C — every extra degree wastes 4% energy',        impact: 'Cooling efficiency +4%' },
  { id: 9, icon: '☀️', tip: 'Route non-critical workloads to solar-powered cloud regions when available', impact: 'Up to 100% clean energy use' },
  { id:10, icon: '🔋', tip: 'Use power-efficient network equipment rated 80 Plus Gold or above',      impact: 'Reduces PSU losses by 15%' },
];

const auditLogs = [
  { id: 1, user: 'admin@cybershield.ai',   action: 'FIREWALL_RULE_ADDED',   detail: 'Rule #847 — Block SQL injection pattern',   time: Date.now()-120000  },
  { id: 2, user: 'analyst@cybershield.ai', action: 'IP_BLOCKED',            detail: 'IP 185.220.101.42 added to blocklist',      time: Date.now()-480000  },
  { id: 3, user: 'system',                 action: 'AI_MODEL_RETRAINED',    detail: 'Random Forest retrained — 2,341 new samples',time: Date.now()-3600000 },
  { id: 4, user: 'analyst@cybershield.ai', action: 'INCIDENT_RESOLVED',     detail: 'Incident #5 resolved — false positive',     time: Date.now()-7200000 },
  { id: 5, user: 'system',                 action: 'ECO_OPTIMIZER_ENABLED', detail: 'Off-peak mode activated — saving 340W',     time: Date.now()-10800000},
];

module.exports = { JWT_SECRET, users, incidents, firewallRules, threatFeed, blacklistedIPs, cveList, ecoMetrics, ecoTips, auditLogs };
